# crappyClippy
CS408 project repo!

## Installation Instructions
While the extension is in development, please follow these instructions to install it in Chrome.
1. Pull a stable version
2. Open Chrome and go to [chrome://extensions](chrome://extensions)
3. Make sure that **Developer Mode** is checked
4. Click **Load unpacked extension...**
5. Select the location of the extension on your machine
6. Make sure that **enabled** is checked for the extension
7. When you make changes to the extension on your machine, it should update in Chrome. You may have to go back to [chrome://extensions](chrome://extensions) and click **Reload** to reload the extension